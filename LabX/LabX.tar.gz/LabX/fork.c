#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h> // Include this for wait()

int main() {
    printf("Parent Process: PID = %d\n", getpid());

    for (int i = 0; i < 3; i++) {
        pid_t pid = fork();

        if (pid < 0) {
            // Error occurred during fork
            perror("Fork failed");
            return 1;
        } else if (pid == 0) {
            // Child process
            printf("Child Process: PID = %d, Parent PID = %d\n", getpid(), getppid());
            // Exit to prevent the child process from continuing the loop
            return 0;
        }
        // Parent process continues the loop
    }

    // Allow the parent to wait for all child processes (optional, for cleanup)
    while (wait(NULL) > 0);

    return 0;
}
