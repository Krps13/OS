#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>  // Include this for wait()


int main() {
    int pipefd[2];  // Array to hold the pipe file descriptors
    pid_t pid;

    // Create the pipe
    if (pipe(pipefd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    // Fork a child process
    pid = fork();

    if (pid < 0) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {  // Child process
        close(pipefd[1]); // Close the write end of the pipe

        char buffer[100];
        ssize_t bytesRead = read(pipefd[0], buffer, sizeof(buffer) - 1);

        if (bytesRead > 0) {
            buffer[bytesRead] = '\0'; // Null-terminate the string
            printf("Child received: %s\n", buffer);
        } else {
            perror("read");
        }

        close(pipefd[0]); // Close the read end of the pipe
    } else {  // Parent process
        close(pipefd[0]); // Close the read end of the pipe

        const char *message = "Hello from parent!";
        printf("Parent sending: %s\n", message);

        if (write(pipefd[1], message, strlen(message)) == -1) {
            perror("write");
        }

        close(pipefd[1]); // Close the write end of the pipe
        wait(NULL); // Wait for the child process to finish
    }

    return 0;
}
