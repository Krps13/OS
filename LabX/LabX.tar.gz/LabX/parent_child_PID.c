#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define FILE_NAME "parent_child_ids.txt"

int main() {
    pid_t pid;
    FILE *file;

    // Open the file for writing (append mode)
    file = fopen(FILE_NAME, "a");
    if (file == NULL) {
        perror("Failed to open file");
        exit(EXIT_FAILURE);
    }

    // Create child process
    pid = fork();

    if (pid < 0) {
        // Fork failed
        perror("Fork failed");
        fclose(file);
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        // Child process
        fprintf(file, "Child PID: %d\n", getpid());
        fclose(file);
        exit(EXIT_SUCCESS);
    } else {
        // Parent process
        fprintf(file, "Parent PID: %d\n", getpid());
        fclose(file);

        // Wait for child process to complete
        wait(NULL);
    }

    return 0;
}
