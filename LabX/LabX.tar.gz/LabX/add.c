#include <stdio.h>

// Function to add three integers passed by reference
int add(int *a, int *b, int *c) {
    return *a + *b + *c;
}

int main() {
    int num1, num2, num3;
    
    // Input three integers
    printf("Enter three integers: ");
    scanf("%d %d %d", &num1, &num2, &num3);

    // Call add() and print the result
    int sum = add(&num1, &num2, &num3);
    printf("The sum of %d, %d, and %d is: %d\n", num1, num2, num3, sum);

    return 0;
}
