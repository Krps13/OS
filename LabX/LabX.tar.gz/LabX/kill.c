#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

// Signal handler for the child process
void signal_handler(int sig) {
    if (sig == SIGUSR1) {
        printf("Child received SIGUSR1 signal from parent.\n");
        exit(0); // Exit after handling the signal
    }
}

int main() {
    pid_t pid;

    // Fork a child process
    pid = fork();

    if (pid < 0) {
        perror("fork");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {  // Child process
        // Register the signal handler
        signal(SIGUSR1, signal_handler);

        printf("Child process waiting for signal...\n");

        // Wait indefinitely for a signal
        while (1) {
            pause(); // Suspend execution until a signal is received
        }
    } else {  // Parent process
        sleep(1); // Give child process time to set up the signal handler

        printf("Parent sending SIGUSR1 to child process.\n");

        // Send SIGUSR1 signal to the child process
        if (kill(pid, SIGUSR1) == -1) {
            perror("kill");
            exit(EXIT_FAILURE);
        }

        // Wait for the child process to terminate
        wait(NULL);
        printf("Child process terminated.\n");
    }

    return 0;
}
